﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace Teste_Serial
{
    public partial class SerialForm : Form
    {
        public SerialForm()
        {
            InitializeComponent();
        }

        private void SerialForm_Load(object sender, EventArgs e)
        {
            string[] portas = SerialPort.GetPortNames();

            cbx_portacom.Sorted = true;

            foreach(var ports in portas)
            {
                cbx_portacom.Items.Add(ports);
            }


            if(cbx_portacom.Items.Count > 0)
            {
                cbx_portacom.SelectedIndex = 0;
            }
        }

        private void TarefaLonga(int p)
        {
            for (int i = 0; i <= 10; i++)
            {
                Thread.Sleep(p);
                lbl_testeenvio.BeginInvoke(
                    new Action(() =>
                    {
                        lbl_testeenvio.Text = "Teste Serial  " + i.ToString() + "Concluido";
                    }
                   ));
            }
        }

        private void btn_abrirporta_Click(object sender, EventArgs e)
        {
            if (spPorts.IsOpen)
            {
                btn_abrirporta.Text = "Abrir";
                spPorts.Close();
            }
            else
            {
                if(cbx_portacom.Text == "")
                {
                    MessageBox.Show("Nao Foi possivel abrir uma porta serial", "Error Porta serial" , MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    btn_abrirporta.Text = "Fechar";
                    spPorts.PortName = cbx_portacom.Text;
                    spPorts.BaudRate = 9600;
                    spPorts.Open();
                }
                
            }

            btn_enviar.Enabled = txt_envios.Enabled = spPorts.IsOpen;
        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            if (txt_envios.Text == "")
            {
                MessageBox.Show("Nao Foi possivel enviar uma porta serial", "Error Porta serial", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else {
                spPorts.Write(txt_envios.Text);
            }
            
            //desabilita os botões enquanto a tarefa é executada
            btn_enviar.Enabled = false;

            //define o stilo padrao do progressbar
            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = 0;

            //executa o processo de forma assincrona.
            backgroundWorker1.RunWorkerAsync();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void spComunica_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            BeginInvoke((MethodInvoker) (() => { txt_receber.Text += spPorts.ReadExisting(); } ));

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < 100; i++)//representa uma tarefa com 100 processos.
            {
                TarefaLonga(20);
                //incrementa o progresso do backgroundWorker
                //a cada passagem do loop.
                this.backgroundWorker1.ReportProgress(i);

                //Verifica se houve uma requisição para cancelar a operação.
                if (backgroundWorker1.CancellationPending)
                {
                    //se sim, define a propriedade Cancel para true
                    //para que o evento WorkerCompleted saiba que a tarefa foi cancelada.
                    e.Cancel = true;

                    //zera o percentual de progresso do backgroundWorker1.
                    backgroundWorker1.ReportProgress(0);
                    return;
                }
            }
            //Finalmente, caso tudo esteja ok, finaliza
            //o progresso em 100%.
            backgroundWorker1.ReportProgress(100);
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //Incrementa o valor da progressbar com o valor
            //atual do progresso da tarefa.
            progressBar1.Value = e.ProgressPercentage;

            //informa o percentual na forma de texto.
            label1.Text = e.ProgressPercentage.ToString() + "%";
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                //caso a operação seja cancelada, informa ao usuario.
                lbl_testeenvio.Text = "Operação Cancelada!";

                //limpa a label
                lbl_testeenvio.Text = string.Empty;
            }
            else if (e.Error != null)
            {
                //informa ao usuario do acontecimento de algum erro.
                lbl_testeenvio.Text = "Aconteceu um erro durante a execução do processo!";
            }
            else
            {
                //informa que a tarefa foi concluida com sucesso.
                lbl_testeenvio.Text = "Serial Enviada!";
            }
            //habilita os botões.
        }
    }
}
